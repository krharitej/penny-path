package com.haritejkr.pennypath.ui.screens.goals

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.haritejkr.pennypath.logic.goals.AddGoal
import com.haritejkr.pennypath.logic.goals.DeleteGoal
import com.haritejkr.pennypath.logic.goals.GetGoal
import com.haritejkr.pennypath.logic.goals.UpdateGoal
import com.haritejkr.pennypath.model.Goal
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class GoalViewModel @Inject constructor(
    private val getGoals: GetGoal,
    private val addGoal: AddGoal,
    private val updateGoal: UpdateGoal,
    private val deleteGoal: DeleteGoal
) : ViewModel() {

    val goals = getGoals().stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        emptyList()
    )

    fun addGoal(goal: Goal) {
        viewModelScope.launch {
            addGoal(goal)
        }
    }

    fun removeGoal(goal: Goal) {
        viewModelScope.launch {
            deleteGoal(goal)
        }
    }

    fun addMoney(goal: Goal, amount: Double) {
        viewModelScope.launch {
            updateGoal(
                goal.copy(savedAmount = goal.savedAmount + amount)
            )
        }
    }
}