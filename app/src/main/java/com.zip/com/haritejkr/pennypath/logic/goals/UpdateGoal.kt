package com.haritejkr.pennypath.logic.goals

import com.haritejkr.pennypath.data.local.entity.Goal
import com.haritejkr.pennypath.repository.GoalRepository
import javax.inject.Inject

class UpdateGoal @Inject constructor(
    private val repository: GoalRepository
) {
    suspend operator fun invoke(goal: Goal) {
        repository.updateGoal(goal)
    }
}